﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class DatePickerController : Controller
    {
        public ActionResult Globalization()
        {
            return View();
        }
    }
}