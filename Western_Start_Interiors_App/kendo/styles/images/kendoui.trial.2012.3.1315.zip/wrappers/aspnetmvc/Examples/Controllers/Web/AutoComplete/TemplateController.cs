﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class AutoCompleteController : Controller
    {
        public ActionResult Template()
        {
            return View();
        }
    }
}