﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Linear_GaugeController : Controller
    {
        public ActionResult Scale_Options()
        {
            return View();
        }
    }
}