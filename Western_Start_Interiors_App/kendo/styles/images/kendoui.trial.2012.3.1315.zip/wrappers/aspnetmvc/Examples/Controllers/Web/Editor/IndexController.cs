﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class EditorController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ImageBrowser()
        {
            return View();
        }
    }
}