﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Radial_GaugeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}