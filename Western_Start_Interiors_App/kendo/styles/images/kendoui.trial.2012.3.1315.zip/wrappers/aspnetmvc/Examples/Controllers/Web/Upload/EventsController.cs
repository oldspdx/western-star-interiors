﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class UploadController : Controller
    {
        public ActionResult Events()
        {
            return View();
        }
    }
}