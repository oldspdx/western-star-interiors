﻿namespace Kendo.Mvc.Examples.Controllers
{
    using System.Web.Mvc;

    public partial class DropDownListController : Controller
    {
        public ActionResult RemoteDataSource()
        {
            return View();
        }
    }
}