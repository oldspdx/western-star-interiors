﻿using System;
using System.Linq;
using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class Area_ChartsController : Controller
    {
        public ActionResult Grouped_Data()
        {
            return View();
        }
    }
}