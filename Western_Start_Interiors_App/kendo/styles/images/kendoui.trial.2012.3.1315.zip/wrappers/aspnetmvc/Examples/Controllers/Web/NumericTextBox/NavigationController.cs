﻿using System.Web.Mvc;

namespace Kendo.Mvc.Examples.Controllers
{
    public partial class NumericTextBoxController : Controller
    {
        public ActionResult Navigation()
        {
            return View();
        }
    }
}